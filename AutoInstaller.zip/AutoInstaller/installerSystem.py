import subprocess
import time

packageName="ufw"
packageName1="suricata"
resultInstaller = subprocess.run(["sudo", "apt", "install", "-y", packageName, packageName1], check=True)

print(resultInstaller.stdout)
print("Installed UFW and Suricata...")

print("Beginning the copying and creation of base files...")
time.sleep(3)

resultCopyBeforeRules = subprocess.run(["sudo", "cp", "beforerules.txt", "/etc/ufw/before.rules"], check=True)

resultCopyUserRules = subprocess.run(["sudo", "cp", "userrules.txt", "/etc/ufw/user.rules"], check=True)

resultCopyUser6Rules = subprocess.run(["sudo", "cp", "user6rules.txt", "/etc/ufw/user6.rules"], check=True)

resultCopyBefore6Rules = subprocess.run(["sudo", "cp", "before6rules.txt", "/etc/ufw/before6.rules"], check=True)

resultMakeSuricataDir = subprocess.run(["sudo", "mkdir", "-p", "/etc/systemd/system/suricata.service.d/"], check=False)
resultMakeLocalRules = subprocess.run(["sudo", "touch", "/etc/suricata/rules/local.rules"], check=True)

resultCreateOverrideSuricata = subprocess.run(["sudo", "touch", "/etc/systemd/system/suricata.service.d/override.conf"], check=True)

resultCopyOverrideSuricata = subprocess.run(["sudo", "cp", "overrideconf.txt", "/etc/systemd/system/suricata.service.d/override.conf"], check=True)

resultSetDefaultOutgoing = subprocess.run(["sudo", "ufw", "default", "deny", "outgoing"],check=True)
resultSetDefaultIncoming = subprocess.run(["sudo", "ufw", "default", "deny", "incoming"],check=True)

print("Beginning the reset of files to ensure they work correctly...")
time.sleep(3)
resultStartUfw = subprocess.run(["sudo", "ufw", "enable"],check=True)
resultReloadDaemon = subprocess.run(["sudo", "systemctl", "daemon-reload"],check=True)
resultReloadSuricata = subprocess.run(["sudo", "systemctl", "restart", "suricata"],check=True)
resultReloadUFW = subprocess.run(["sudo", "systemctl", "restart", "ufw"],check=True)

print("Beginning Reboot in 10 seconds...")
time.sleep(10)
resultReboot = subprocess.run(["reboot"],check=False)
# curl -sSL https://install.pi-hole.net | bash
#resultInstallPiHole = subprocess.run(["sudo", "curl", "-sSL", "https://install.pi-hole.net", "|" , "bash"], check=True)
#git clone --depth 1 https://github.com/pi-hole/pi-hole.git Pi-hole
#cd "Pi-hole/automated install/"
#sudo bash basic-install.sh
